﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gasolinera
{
    internal class Trabajador
    {
        string nombre;
        int id;
        double salario;
        string sede; 
        public Trabajador() { }

    }
}
