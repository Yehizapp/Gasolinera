﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gasolinera
{
    internal class Surtidor
    {
        bool gasolina;
        string corriente;
        string extra;
        int precioExtra;
        int precioCorriente;
        bool disponibilidad; 
        public Surtidor() { }
       
    }
}
