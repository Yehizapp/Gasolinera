﻿namespace Gasolinera
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int sede; 
            Console.WriteLine("Bienvenido a la gasolinera PecasTurbo");
            
        }
    }
}
