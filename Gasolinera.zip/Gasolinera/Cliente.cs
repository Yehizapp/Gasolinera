﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gasolinera
{
    internal class Cliente
    {
        public Cliente() { }    
        string nombre;
        int cedula;
        int numero;
        bool puntos; 
    }
    
}
