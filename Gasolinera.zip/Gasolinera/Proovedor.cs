﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gasolinera
{
    internal class Proovedor
    {
        string empresa;
        int numContrato;
        DateTime fechaSurtir; 
        public Proovedor() { }
    }
}
